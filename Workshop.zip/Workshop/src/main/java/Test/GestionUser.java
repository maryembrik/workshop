package Test;

import Utiles.MyDb;

public class GestionUser {
    public static void main(String[] args){
        MyDb db =   MyDb.getInstance();
    }
}
